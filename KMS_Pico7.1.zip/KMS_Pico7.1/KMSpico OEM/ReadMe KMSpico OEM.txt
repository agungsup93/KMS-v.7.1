Important: If you like MS Windows and MS Office please buy legal and original
			this program help to test this products, but recommend you buy legal.
			I did this for fun, and now I am done with this. 
			Working in W8 and Office 2013 fresh install and VOLUMEN LICENSE editions.
			Ja mata ne, Farewell, Hejd�, Ciao, Aloha, Zegnaj, Doei

KMSpico v7.1 OEM Edition.

- Requirements: .NET 4.0 or Windows 8/2012.
- Activate: Windows Vista/7/8/(8.1 Preview)
			Office 2010/2013 
			Windows Server 2008/2008R2/2012

1. Copy the $OEM$ folder inside of the Windows ISO image (inside of sources folder).
2. Install the O.S. from the iso modified.
3. Done.

Based off of KMSEmulator of CODYQX4,Hotbird64,qad,deagles.

Thanks to Hotbird64, deagles, mikmik38, qad, CODYQX4, xinso. All the credits for they.
Thanks MyDigitalLife.info
Thanks hui.

Recommendations Optional:

- Make exceptions to Directory %ProgramFiles%\KMSpico\*.exe in Antivirus or Defender.

How This Program Works:

1. It install automatically KMSpico v7.1 Install Edition at the end of the Windows 8 installation.

Change Log:
- Fixed bug with fresh install without VC++ Runtime Installed.}
- Added buttoms Create Tokens Backup and Restore Tokens Backup.
- Added automatic installation of certificades in corrupted office installation.
- Small dll server.
- Improved emulador charge.
- Fixed minor bugs.
- Improved log files.