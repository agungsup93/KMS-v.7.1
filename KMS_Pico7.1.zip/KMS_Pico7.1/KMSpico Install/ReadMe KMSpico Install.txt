Important: If you like MS Windows and MS Office please buy legal and original
			this program help to test this products, but recommend you buy legal.
			I did this for fun, and now I am done with this. 
			Working in W8 and Office 2013 fresh install and VOLUMEN LICENSE editions.
			Ja mata ne, Farewell, Hejd�, Ciao, Aloha, Zegnaj, Doei

KMSpico v7.1 Setup Edition.

- Requirements: .NET 4.0 or Windows 8/2012.
- Activate: Windows Vista/7/8/(8.1 Preview) 
			Office 2010/2013 
			Windows Server 2008/2008R2/2012

0. Disable SmartScreen on Windows 8.
1. Run KMSpico_Install_v7.1.exe
2. Install it.
2.1 (Optional) Create a tokens backup with the buttom: Create.
3. Press the Red Buttom.
3. Done.

Based off of KMSEmulator of CODYQX4,Hotbird64,qad,deagles.

Thanks to Hotbird64, deagles, mikmik38, qad, CODYQX4, xinso. All the credits for they.
Thanks MyDigitalLife.info
Thanks hui.

Recommendations Optional:

- Make exceptions to Directory %ProgramFiles%\KMSpico\*.exe in Antivirus or Defender.

How This Program Works:

1. Install KMSpico v7.1 in Windows.
2. Run automatically KMSELDI and AutoPico.
2.1 Make Tokens Backup.
2.2 Detect VL or Retail and depending of the License Status activate or convert to VL.
2.3 Activate for 180 days all VL products found.
3. Install a windows service that reactive every windows start.
4. Create a task schedule for AutoPico to run every 24 hours.

Change Log:
- Fixed bug with fresh install without VC++ Runtime Installed.}
- Added buttoms Create Tokens Backup and Restore Tokens Backup.
- Added automatic installation of certificades in corrupted office installation.
- Small dll server.
- Improved emulador charge.
- Fixed minor bugs.
- Improved log files.

By:

WORLD OF CRACKS - A BLOG AT YOUR SERVICE 
        www.saisoftwarecracks.com
        
FACEBOOK: www.facebook.com/worldofcracks       
TWITTER: www.twitter.com/WORLDOFCRACKS
