Important: If you like MS Windows and MS Office please buy legal and original
			this program help to test this products, but recommend you buy legal.
			I did this for fun, and now I am done with this. 
			Working in W8 and Office 2013 fresh install and VOLUMEN LICENSE editions.
			Ja mata ne, Farewell, Hejd�, Ciao, Aloha, Zegnaj, Doei

KMSpico v7.1 Portable Edition

- Requirements: .NET 4.0 or Windows 8/2012.
- Activate: Windows Vista/7/8/(8.1 Preview)
			Office 2010/2013 
			Windows Server 2008/2008R2/2012

0. Disable SmartScreen.
1. Run AutoPico.exe
2. Done.

For Task Schedule:
0. Disable SmartScreen.
1. Run Install_Task.cmd
2. Done.

Based off of KMSEmulator of CODYQX4,Hotbird64,qad,deagles.

Thanks to Hotbird64, deagles, mikmik38, qad, CODYQX4, xinso. All the credits for they.
Thanks MyDigitalLife.info
Thanks hui.

Recommendations Optional:

- Make exceptions to Directory %ProgramFiles%\KMSpico\*.exe in Antivirus or Defender.

How This Program Works:

1. Check Activation Status
2. Detect VL or Retail (Windows) and depending of the License Status activate or convert to VL.
3. Receive two command line options: /backup and /silent

Change Log:
- Fixed bug with fresh install without VC++ Runtime Installed.}
- Added buttoms Create Tokens Backup and Restore Tokens Backup.
- Added automatic installation of certificades in corrupted office installation.
- Small dll server.
- Improved emulador charge.
- Fixed minor bugs.
- Improved log files.
